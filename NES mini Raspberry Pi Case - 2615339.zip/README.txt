NES mini Raspberry Pi Case by Classic-Cases on Thingiverse: https://www.thingiverse.com/thing:2615339

Summary:
Inspired by the original NES console and recent NES ClassicScaled to eliminate the need for connector extensionsFeatures an easily removable top for quick accessCartridge 'door' hinges to reveal the PI and power lights (i.e. non-functional, for cool-factor only)Snug and secure fit for your Raspberry Pi 